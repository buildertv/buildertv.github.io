
Const sTaskName = "Notify Anniversary"
Const sStartTime = "15:06:00"
Dim sTask
sTask = "schtasks /create /sc ONCE /tn """ & sTaskName & """ /tr " & _
        """wscript.exe 'C:\BuilderTV\nhacHen\AnniversaryScript.vbs'""" & _
        " /sd " & Date & " /st " & sStartTime & " /f"
CreateObject("Wscript.Shell").Run sTask, 0, True