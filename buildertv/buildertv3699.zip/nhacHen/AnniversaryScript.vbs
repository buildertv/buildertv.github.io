
On Error Resume Next
Const sSourceFile = "C:\BuilderTV\nhacHen\AnniversaryData.txt"
Dim oFile, sLine, dDate, lDays, lDay, i, sPrompt
Dim aDays(9)
lDays = UBound(aDays, 1)
Set oFile = CreateObject("Scripting.FileSystemObject").OpenTextFile(sSourceFile, 1, , -2)
Do Until oFile.AtEndOfStream
    sLine = oFile.ReadLine
    If sLine <> "" Then
        dDate = GetDate(sLine)
        lDay = dDate - Date
        If lDay < lDays Then
        aDays(lDay) = aDays(lDay) & vbNewLine & "  - " & sLine
        End If
    End If
Loop
For i = 0 To lDays - 1
    If aDays(i) <> "" Then
        sPrompt = sPrompt & vbNewLine & FormatDate(Date + i) & Mid(aDays(i), 1)
    End If
Next
oFile.Close
If sPrompt <> "" Then
    MsgBox Mid(sPrompt, 3), 4096, "Nh" & ChrW(7855) & "c nh" & ChrW(7903)
End If
Function GetDate(ByRef sLine)
    Dim aArr, aDate
    aArr = Split(sLine, vbTab)
    sLine = aArr(0)
    aDate = Split(Trim(aArr(1)), "/")
    GetDate = DateSerial(Year(Date), aDate(1), aDate(0))
    If GetDate < Date Then
        GetDate = DateSerial(Year(Date) + 1, aDate(1), aDate(0))
    End If
End Function
Function FormatDate(ByVal dDate)
Dim lWD
If dDate = Date Then
    FormatDate = "H" & ChrW(244) & "m nay"
Else
    lWD = Weekday(dDate, 1)
    If lWD = 1 Then
        FormatDate = "Ch" & ChrW(7911) & " nh" & ChrW(7853) & "t"
    Else
        FormatDate = "Th" & ChrW(7913) & " " & lWD
    End If
End If
FormatDate = FormatDateTime(dDate) & " (" & FormatDate & ")"
End Function